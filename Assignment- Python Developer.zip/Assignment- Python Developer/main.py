from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sqlite3
from sqlite3 import Error
from geopy.distance import geodesic

app = FastAPI()

class Address(BaseModel):
    name: str
    address: str
    lat: float
    lon: float

def create_connection():
    conn = None
    try:
        conn = sqlite3.connect('addresses.db')
    except Error as e:
        print(e)

    return conn

@app.post("/address")
def create_address(address: Address):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO addresses (name, address, lat, lon) VALUES (?, ?, ?, ?)',
                   (address.name, address.address, address.lat, address.lon))
    conn.commit()
    address_dict = address.dict()
    address_dict['id'] = cursor.lastrowid
    return address_dict

@app.put("/address/{address_id}")
def update_address(address_id: int, address: Address):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM addresses WHERE id=?', (address_id,))
    row = cursor.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Address not found")
    cursor.execute('UPDATE addresses SET name=?, address=?, lat=?, lon=? WHERE id=?',
                   (address.name, address.address, address.lat, address.lon, address_id))
    conn.commit()
    address_dict = address.dict()
    address_dict['id'] = address_id
    return address_dict

@app.delete("/address/{address_id}")
def delete_address(address_id: int):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM addresses WHERE id=?', (address_id,))
    row = cursor.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Address not found")
    cursor.execute('DELETE FROM addresses WHERE id=?', (address_id,))
    conn.commit()
    return {"message": "Address deleted successfully"}

@app.get("/addresses")
def get_addresses():
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM addresses')
    rows = cursor.fetchall()
    addresses = []
    for row in rows:
        address = {
            "id": row[0],
            "name": row[1],
            "address": row[2],
            "lat": row[3],
            "lon": row[4]
        }
        addresses.append(address)
    return addresses

@app.get("/addresses/nearby")
def get_addresses_nearby(lat: float, lon: float, distance: float):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM addresses')
    rows = cursor.fetchall()
    addresses = []
    for row in rows:
        if geodesic((lat, lon), (row[3], row[4])).km <= distance:
            address = {
                "id": row[0],
                "name": row[1],
                "address": row[2],
                "lat": row[3],
                "lon": row[4]
            }
            addresses.append(address)
    return addresses

if __name__ == "__main__":
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('CREATE TABLE IF NOT EXISTS addresses (id INTEGER PRIMARY KEY, name TEXT, address TEXT, lat REAL, lon REAL)')
    conn.commit()
    uvicorn.run(app, host="0.0.0.0", port=8000)
